export interface Update {
    id: number;
    value: any;
}
